package atm_java;

//import java.awt.EventQueue;
import javax.swing.JFrame;
//import javax.swing.JTextArea;
import java.awt.Font;
//import java.awt.Image;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
//import javax.swing.ImageIcon;
import javax.swing.JButton;
//import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class DELETECUSTOMER {
				private JFrame frame;
				private JTextField textField;
				//private JTextField textField_1;
				//private JTextField textField_2;
				Connection con;
				Statement stmt;
				ResultSet rs;
				//private JTextField textField_3;
				/**
				 * Create the application.
				 */
public DELETECUSTOMER() {
					try 
					{
						Class.forName("oracle.jdbc.driver.OracleDriver");
					} 
					catch (Exception e) 
					{
						System.err.println("Unable to find and load driver");
						System.exit(1);
					}
					connectToDB();
					initialize();
					this.frame.setVisible(true);
				}
void connectToDB() 
				{
						try 
						{
						 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sneha","3334");
						  stmt = con.createStatement();

						} 
						catch (SQLException connectException) 
						{
						  System.out.println(connectException.getMessage());
						  System.out.println(connectException.getSQLState());
						  System.out.println(connectException.getErrorCode());
						  System.exit(1);
						}
				 }
				/**
				 * Initialize the contents of the frame.
				 */
private void initialize() {
					frame = new JFrame();
					frame.setBounds(100, 100, 854, 505);
					frame.setTitle("ATM SOFTWARE");
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.getContentPane().setLayout(null);
				
					JLabel lblNewLabel = new JLabel("CUSTOMER_ID:");
					lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
					lblNewLabel.setBounds(124, 216, 139, 29);
					frame.getContentPane().add(lblNewLabel);
					
					textField = new JTextField();
					textField.setBounds(272, 218, 96, 29);
					frame.getContentPane().add(textField);
					textField.setColumns(20);
					
					
					final JButton btnNewButton = new JButton("DELETE");
					btnNewButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							
							if (e.getSource() == btnNewButton) {
								try {
								  String customer_id;
						           
						            customer_id=textField.getText();   
						            	
						               
						            	 PreparedStatement pstmt = con.prepareStatement("delete from customer where customer_id=(?)");
						            	        pstmt.setString(1, customer_id);        
						            	        int i=pstmt.executeUpdate();
										JOptionPane.showMessageDialog(null, "\nDeleted " + i + " rows successfully");
										frame.dispose();
						          }
						               
						            catch(Exception E)
						            { 
						            	JOptionPane.showMessageDialog(null, "Wrong Entry!!!");
						            	System.out.println(E);
						            }  
						}
							
							
							
						}
							
					});
					btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
					btnNewButton.setBounds(160, 356, 104, 38);
					frame.getContentPane().add(btnNewButton);
					
					JLabel lblNewLabel_3 = new JLabel("DELETE CUSTOMER ACCOUNT");
					lblNewLabel_3.setFont(new Font("Monospaced", Font.BOLD, 27));
					lblNewLabel_3.setBounds(168, 37, 399, 47);
					frame.getContentPane().add(lblNewLabel_3);
					
					JLabel lblNewLabel_1 = new JLabel("");
					lblNewLabel_1.setBounds(458, 99, 356, 295);
			
				}
			}
