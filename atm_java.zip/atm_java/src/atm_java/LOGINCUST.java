package atm_java;

import java.awt.EventQueue;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
//import javax.swing.JMenu;
//import javax.swing.JMenuBar;
//import javax.swing.JMenuItem;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
 class LOGINCUST{

	private JFrame frame;
	private JTextField t1,t2;
	private JLabel lblNewLabel_1;
	private JButton btnNewButton;
	ProjectUI pu;
	//private JPasswordField passwordField;
	Connection con;
	Statement stmt;
	ResultSet rs;
	/**
	 * Launch the application.
	 */
 	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LOGIN window = new LOGIN();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}); 
	} 

	/**
	 * Create the application.
	 */
	public LOGINCUST() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
	}
	public void connectToDB() 
    {
		try 
		{
		 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sneha","3334");
		  stmt = con.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setTitle("ATM SOFTWARE");
		frame.setBounds(100, 100, 805, 496);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTextArea textArea = new JTextArea("BANK ADMIN");
		textArea.setFont(new Font("Algerian", Font.BOLD, 20));
		textArea.setBackground(Color.YELLOW);
		textArea.setBounds(270, 72, 160, 31);
		frame.getContentPane().add(textArea);
		
		t1 = new JTextField();
		t1.setBounds(297, 183, 178, 31);
		frame.getContentPane().add(t1);
		t1.setColumns(20);
		
		JLabel lblNewLabel = new JLabel("ACCESS NO:");
		lblNewLabel.setFont(new Font("Algerian", Font.BOLD, 15));
		lblNewLabel.setBounds(157, 181, 144, 31);
		frame.getContentPane().add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("PIN:");
		lblNewLabel_1.setFont(new Font("Algerian", Font.BOLD, 15));
		lblNewLabel_1.setBounds(157, 260, 135, 29);
		frame.getContentPane().add(lblNewLabel_1);
		
		t2 = new JTextField();
		t2.setBounds(297, 260, 177, 29);
		frame.getContentPane().add(t2);
		t2.setColumns(10);
		btnNewButton = new JButton("LOGIN");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
					String bank_access_number;
		            String baccess_pin;
		            bank_access_number = t1.getText();
		            baccess_pin= t2.getText();
		            try {
		            
		            rs = stmt.executeQuery("SELECT * FROM bank_admin");
		            while(rs.next()) {
		       
		            	if(rs.getString(5).equals(bank_access_number) && rs.getString(6).equals(baccess_pin)) {
		            		pu=new ProjectUI();
			                  frame.dispose();
			                  break;
		            	}
		            }
		            if(!rs.next()) {
		            	JOptionPane.showMessageDialog(null, "Invalid Login details...!!!");
		            }
		
		            }
		            catch(Exception E)
		            { System.out.println(E);}  
		}
			}
		});
		btnNewButton.setBounds(259, 352, 173, 37);
		frame.getContentPane().add(btnNewButton);
		
		
	}
}
