package atm_java;

//import java.awt.EventQueue;
import javax.swing.JFrame;

import java.awt.Container;
//import javax.swing.JTextArea;
import java.awt.Font;
//import java.awt.Image;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
//import javax.swing.ImageIcon;
import javax.swing.JButton;
//import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class FASTCASH{
				private JFrame frame;
				private JTextField textField;
				//private JTextField textField_1;
				//private JTextField textField_2;
				Connection con;
				Statement stmt;
				ResultSet rs;
				private JTextField textField_1;
				//private JTextField textField_3;
				/**
				 * Create the application.
				 */
public FASTCASH() {
					try 
					{
						Class.forName("oracle.jdbc.driver.OracleDriver");
					} 
					catch (Exception e) 
					{
						System.err.println("Unable to find and load driver");
						System.exit(1);
					}
					connectToDB();
					initialize();
					this.frame.setVisible(true);
				}
void connectToDB() 
				{
						try 
						{
						 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sneha","3334");
						  stmt = con.createStatement();

						} 
						catch (SQLException connectException) 
						{
						  System.out.println(connectException.getMessage());
						  System.out.println(connectException.getSQLState());
						  System.out.println(connectException.getErrorCode());
						  System.exit(1);
						}
				 }
				/**
				 * Initialize the contents of the frame.
				 */
private void initialize() {
	
			frame = new JFrame();
			frame.setBounds(150, 150, 918, 600);
			frame.setTitle("ATM SOFTWARE");
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JLabel lblNewLabel = new JLabel("CUSTOMER_ID:");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel.setBounds(87, 50, 132, 29);
			frame.getContentPane().add(lblNewLabel);
			
			textField = new JTextField();
			textField.setBounds(299, 43, 189, 28);
			frame.getContentPane().add(textField);
			textField.setColumns(10);
			
			
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			final JButton btnNewButton = new JButton("100");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (e.getSource() == btnNewButton) {
					
				            String customer_id = textField.getText();
				           try {
				           
				            	// PreparedStatement pstmt = con.prepareStatement("insert into customer(customer_id,customer_name,customer_dob,customer_number,account_number,card_number,card_pin,b_branch_id,balance) values (?,?,?,?,?,?,?,?,?)");
				        	   PreparedStatement pstmt = con.prepareStatement("update customer set balance=balance - " +100 +"  where customer_id=(?)");
				        	   pstmt.setString(1, customer_id);
				            	      
				            	        int i=pstmt.executeUpdate();  
							   
								JOptionPane.showMessageDialog(null, "\nupdated");
								frame.dispose();
				            }
				            catch(Exception E)
				            { 
				            	JOptionPane.showMessageDialog(null, "\nCheck the details!!!");
				            	
				            	System.out.println(E);}   
				}
				}
			});
			btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
			btnNewButton.setBounds(27, 200, 197, 37);
			frame.getContentPane().add(btnNewButton);
			
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
final JButton btnNewButton_1 = new JButton("1000");
btnNewButton_1.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnNewButton_1) {
		
	            String customer_id = textField.getText();
	           try {
	           
	            	// PreparedStatement pstmt = con.prepareStatement("insert into customer(customer_id,customer_name,customer_dob,customer_number,account_number,card_number,card_pin,b_branch_id,balance) values (?,?,?,?,?,?,?,?,?)");
	        	   PreparedStatement pstmt = con.prepareStatement("update customer set balance=balance - " +1000 +"  where customer_id=(?)");
	        	   pstmt.setString(1, customer_id);
	            	      
	            	        int i=pstmt.executeUpdate();  
				   
					JOptionPane.showMessageDialog(null, "\nupdated");
					frame.dispose();
	            }
	            catch(Exception E)
	            { 
	            	JOptionPane.showMessageDialog(null, "\nCheck the details!!!");
	            	
	            	System.out.println(E);}   
	}
	}
});
btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
btnNewButton_1.setBounds(27, 250, 197, 37);
frame.getContentPane().add(btnNewButton_1);

frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
final JButton btnNewButton_2 = new JButton("5000");
btnNewButton_2.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnNewButton_2) {
		
	            String customer_id = textField.getText();
	           try {
	           
	            	
	        	   PreparedStatement pstmt = con.prepareStatement("update customer set balance=balance - " +5000 +"  where customer_id=(?)");
	        	   pstmt.setString(1, customer_id);
	            	      
	            	        int i=pstmt.executeUpdate();  
				   
					JOptionPane.showMessageDialog(null, "\nupdated");
					frame.dispose();
	            }
	            catch(Exception E)
	            { 
	            	JOptionPane.showMessageDialog(null, "\nCheck the details!!!");
	            	
	            	System.out.println(E);}   
	}
	}
});
btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 16));
btnNewButton_2.setBounds(27,300, 197, 37);
frame.getContentPane().add(btnNewButton_2);

frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
final JButton btnNewButton_3 = new JButton("10000");
btnNewButton_3.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnNewButton_3) {
		
	            String customer_id = textField.getText();
	           try {
	           
	            	// PreparedStatement pstmt = con.prepareStatement("insert into customer(customer_id,customer_name,customer_dob,customer_number,account_number,card_number,card_pin,b_branch_id,balance) values (?,?,?,?,?,?,?,?,?)");
	        	   PreparedStatement pstmt = con.prepareStatement("update customer set balance=balance - " +10000 +"  where customer_id=(?)");
	        	   pstmt.setString(1, customer_id);
	            	      
	            	        int i=pstmt.executeUpdate();  
				   
					JOptionPane.showMessageDialog(null, "\nupdated");
					frame.dispose();
	            }
	            catch(Exception E)
	            { 
	            	JOptionPane.showMessageDialog(null, "\nCheck the details!!!");
	            	
	            	System.out.println(E);}   
	}
	}
});
btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 16));
btnNewButton_3.setBounds(27, 350, 197, 37);
frame.getContentPane().add(btnNewButton_3);

			
final JButton btnNewButton_4 = new JButton("BACK");
btnNewButton_4.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		frame.dispose();
	}});
btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 16));
btnNewButton_4.setBounds(180, 400, 240, 38);
frame.getContentPane().add(btnNewButton_4);

}}
