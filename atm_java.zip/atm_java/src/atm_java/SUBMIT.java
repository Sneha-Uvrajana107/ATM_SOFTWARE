package atm_java;

//import java.awt.EventQueue;
import javax.swing.JFrame;
//import javax.swing.JTextArea;
//import java.awt.Font;
//import java.awt.Image;
//import javax.swing.JLabel;
import javax.swing.JOptionPane;
//import javax.swing.JTextField;
//import javax.swing.ImageIcon;
//import javax.swing.JButton;
//import java.awt.Color;
//import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.awt.event.ActionEvent;

public class SUBMIT{
				private JFrame frame;
			//	private JTextField textField;
				//private JTextField textField_1;
				//private JTextField textField_2;
				Connection con;
				Statement stmt;
				ResultSet rs;
			//	private JTextField textField_1;
				//private JTextField textField_3;
				/**
				 * Create the application.
				 */
public SUBMIT() {
					try 
					{
						Class.forName("oracle.jdbc.driver.OracleDriver");
					} 
					catch (Exception e) 
					{
						System.err.println("Unable to find and load driver");
						System.exit(1);
					}
					connectToDB();
					initialize();
					this.frame.setVisible(true);
				}
void connectToDB() 
				{
						try 
						{
						 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sneha","3334");
						  stmt = con.createStatement();

						} 
						catch (SQLException connectException) 
						{
						  System.out.println(connectException.getMessage());
						  System.out.println(connectException.getSQLState());
						  System.out.println(connectException.getErrorCode());
						  System.exit(1);
						}
				 }
				/**
				 * Initialize the contents of the frame.
				 */
private void initialize() {
	JOptionPane.showMessageDialog(null, "\nTHANK YOU...!!!");
	
}
			}
