package atm_java;

import javax.swing.JButton;

//import java.awt.EventQueue;

import javax.swing.JFrame;
//import javax.swing.JOptionPane;
import javax.swing.JLabel;
//import javax.swing.JOptionPane;

import java.awt.Font;
//import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import javax.swing.JTextField;
//import javax.swing.ImageIcon;
//import javax.swing.JButton;
//import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/*import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;*/

public class ATMBRANCH {

	private JFrame frame;

	Connection con;
	Statement stmt;
	ResultSet rs;
	
	/**
	 * Create the application.
	 */
	public ATMBRANCH() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		this.frame.setVisible(true);
	}
void connectToDB() 
{
		try 
		{
		 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sneha","3334");
		  stmt = con.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 926, 506);
		frame.setTitle("ATM SOFTWARE");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ATM BRANCH DETAILS");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(300, 50, 300, 29);
		frame.getContentPane().add(lblNewLabel);
		

		JLabel lblNewLabel_1 = new JLabel("ATM PIN : SN7839");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(87, 90, 300, 29);
		frame.getContentPane().add(lblNewLabel_1);
		

		JLabel lblNewLabel_2 = new JLabel("ATM BRANCH : IDIDI");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2.setBounds(87, 130, 300, 29);
		frame.getContentPane().add(lblNewLabel_2);
		

		JLabel lblNewLabel_3 = new JLabel("ATM LOCATION : AR NAGAR");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_3.setBounds(87, 180, 300, 29);
		frame.getContentPane().add(lblNewLabel_3);
		

		JLabel lblNewLabel_4 = new JLabel("ATM ADDRESS : 02-893/A,AR NAGAR,HYDERABAD");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_4.setBounds(87, 230, 600, 29);
		frame.getContentPane().add(lblNewLabel_4);
		

		JLabel lblNewLabel_5 = new JLabel("ATM LOCAL : HYDERABAD");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_5.setBounds(87, 270, 300, 29);
		frame.getContentPane().add(lblNewLabel_5);
		

		JLabel lblNewLabel_6 = new JLabel("ATM PIN CODE : 500045");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_6.setBounds(87, 310, 300, 29);
		frame.getContentPane().add(lblNewLabel_6);
		

		JLabel lblNewLabel_7 = new JLabel("THANK YOU...!!!");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_7.setBounds(300, 350, 300, 29);
		frame.getContentPane().add(lblNewLabel_7);
		
		final JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBounds(180, 400, 240, 38);
		frame.getContentPane().add(btnNewButton);
		
	}
}