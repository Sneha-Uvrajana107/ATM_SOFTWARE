package atm_java;

//import java.awt.EventQueue;

//import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import java.awt.Font;
//import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
//import javax.swing.JLabel;

public class VIEWATMADMIN {

	private JFrame frame;
	private JTable table;
  String[][] tbl=new String[100][100];
  Connection con;
	Statement stmt;
	ResultSet rs;
	//private JLabel lblNewLabel;
	/**
	 * Create the application.
	 */
	VIEWATMADMIN() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		this.frame.setVisible(true);
	}
	 void connectToDB() 
	    {
			try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sneha","3334");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("ATM SOFTWARE");
		frame.setBounds(100, 100, 797, 503);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTextPane txtpnOfficerDetails = new JTextPane();
		txtpnOfficerDetails.setFont(new Font("Monospaced", Font.BOLD, 24));
		txtpnOfficerDetails.setText("ATM ADMIN");
		txtpnOfficerDetails.setBounds(140, 23, 269, 32);
		frame.getContentPane().add(txtpnOfficerDetails);
		try {
			ResultSet rs=stmt.executeQuery("select * from atm_admin");
		
			int i=0;
			while(rs.next()) {		
				tbl[i][0]=rs.getString(1);
				tbl[i][1]=rs.getString(2);
				tbl[i][2]=rs.getString(3); 
				tbl[i][3]=rs.getString(4);
				tbl[i][4]=rs.getString(5);
				tbl[i][5]=rs.getString(6);
				
				i=i+1;
				
			}
			for(i=0;i<10;i++) {
			System.out.println(tbl[i][0]+" "+tbl[i][1]+" "+tbl[i][2]+" "+tbl[i][3]+" "+tbl[i][4]+" "+tbl[i][5]);
			}
			
		
		table = new JTable();
		table.setRowSelectionAllowed(false);
		table.setSurrendersFocusOnKeystroke(true);
		table.setModel(new DefaultTableModel(
			tbl,
			new String[] {
				"ADMIN_ID", "ADMIN_NAME", "ADMIN_DOB","ADMIN_NUMBER","ATM_ACCESS_NUMBER","ACCESS_PIN"
				 
			}
		));
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setBounds(10, 72, 770, 150);
		frame.getContentPane().add(table);
		
	/*	lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(406, 10, 206, 141);
		Image img =  new ImageIcon(this.getClass().getResource("/people-2-icon.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(225,10,400,396);
		frame.getContentPane().add(lblNewLabel);
		*/}
		catch(Exception E)
      { 
			JOptionPane.showMessageDialog(null, "\nIncorrect Approach!");
      	System.out.println(E);
      }  
		
		
	}
}
