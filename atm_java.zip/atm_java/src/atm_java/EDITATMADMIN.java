package atm_java;

//import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import java.awt.Font;
//import java.awt.Image;

import javax.swing.JTextField;
//import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
//import javax.swing.SwingConstants;

public class EDITATMADMIN {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	Connection con;
	Statement stmt;
	ResultSet rs;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	//private JTextField textField_4;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	

	/**
	 * Create the application.
	 */
	public EDITATMADMIN() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		this.frame.setVisible(true);
	}
void connectToDB() 
{
		try 
		{
		 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sneha","3334");
		  stmt = con.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(150, 150, 918, 600);
		frame.setTitle("ATM SOFTWARE");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ADMIN ID:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(87, 50, 132, 29);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ADMIN NAME:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(87, 89, 181, 32);
		frame.getContentPane().add(lblNewLabel_1);
		
		
		JLabel lblNewLabel_2 = new JLabel("ADMIN DOB:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2.setBounds(87, 131, 190, 35);
		frame.getContentPane().add(lblNewLabel_2);
		
		
		JLabel lblNewLabel_3 = new JLabel("ADMIN NUMBER:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_3.setBounds(87, 170, 250, 40);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("ACCESS NUMBER:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_4.setBounds(87, 220, 350, 30);
		frame.getContentPane().add(lblNewLabel_4);
		
		
		JLabel lblNewLabel_5 = new JLabel("ACCESS PIN:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_5.setBounds(87, 250, 450, 60);
		frame.getContentPane().add(lblNewLabel_5);
	
		textField = new JTextField();
		textField.setBounds(299, 43, 189, 28);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(299, 93, 189, 28);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(299, 137, 190, 31);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(299, 170, 190, 31);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(299, 210, 190, 31);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(299, 250, 190, 31);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
	
		
	/*	JLabel lblNewLabel = new JLabel("CUSTOMER_ID:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(87, 50, 132, 29);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("COURSE_DAYS:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(87, 89, 181, 32);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("LICENCE_REQUIRED:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2.setBounds(87, 131, 181, 39);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(299, 43, 189, 28);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(299, 94, 189, 28);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(299, 137, 190, 31);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		/*btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_1.setBounds(488, 395, 120, 39);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_3 = new JLabel("PICKUP_ADDRESS:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_3.setBounds(87, 180, 162, 32);
		frame.getContentPane().add(lblNewLabel_3);
		
		textField_3 = new JTextField();
		textField_3.setBounds(299, 178, 189, 28);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(20); */
		/*
		JLabel lblNewLabel_4 = new JLabel("VEHICLE_NAME:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_4.setBounds(87, 229, 162, 28);
		frame.getContentPane().add(lblNewLabel_4);
		
		textField_4 = new JTextField();
		textField_4.setBounds(299, 231, 189, 29);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("EMAIL_ID:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_5.setBounds(103, 279, 132, 28);
		frame.getContentPane().add(lblNewLabel_5);
		
		textField_5 = new JTextField();
		textField_5.setBounds(299, 283, 189, 26);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("ADDRESS:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_6.setBounds(103, 331, 120, 26);
		frame.getContentPane().add(lblNewLabel_6);
		
		textField_6 = new JTextField();
		textField_6.setBounds(299, 324, 189, 32);
		frame.getContentPane().add(textField_6);
		textField_6.setColumns(10);*/
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		final JButton btnNewButton = new JButton("MODIFY!");
		btnNewButton.addActionListener(new ActionListener() {
			
		    			public void actionPerformed(ActionEvent e) {
		    				if (e.getSource() == btnNewButton) {
		    				    int admin_id;
					            int admin_number;
					            int atm_access_number;
					            int access_pin;
  				          //  int customer_id;
					         //   int balance;
					      //      String licence_required;
					           admin_id = Integer.parseInt(textField.getText());
					          //  customer_name = Integer.parseInt(textField_1.getText());
					        //    customer_dob = Integer.parseInt(textField_2.getText());
					            admin_number = Integer.parseInt(textField_3.getText());
					            atm_access_number = Integer.parseInt(textField_4.getText());
					          //  card_number = Integer.parseInt(textField_5.getText());
					            access_pin = Integer.parseInt(textField_6.getText());
					        //    b_branch_id = Integer.parseInt(textField_7.getText());
					         //   balance = Integer.parseInt(textField_8.getText());
					            
					           // String customer_id = textField.getText();
					            String admin_name = textField_1.getText();
					            String admin_dob = textField_2.getText();
					          //  String b_branch_id = textField_3.getText();
					          //  String account_number = textField_4.getText();
					          //  String card_number = textField_5.getText();
					            
			            try {
			           
			            	 PreparedStatement pstmt = con.prepareStatement("update atm_admin set admin_name=(?),admin_dob=(?),admin_number=(?),atm_access_number=(?),access_pin=(?) where admin_id=(?)");
			            	      
		            	        pstmt.setString(1, admin_name);
		            	        pstmt.setString(2, admin_dob);
		            	        pstmt.setInt(3, admin_number);
		            	        pstmt.setInt(4, atm_access_number);
		            	        pstmt.setInt(5, access_pin);
		            	        pstmt.setInt(6, admin_id); 
		            	        int i=pstmt.executeUpdate();  
						   
							JOptionPane.showMessageDialog(null, "\nUpdated " + i + " rows successfully");
				   }
			            catch(Exception E)
			            { 
			            	JOptionPane.showMessageDialog(null, "\nCheck the details!!!");
			            	//System.out.println(E);
			            	}   
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBounds(206, 479, 189, 39);
		frame.getContentPane().add(btnNewButton);  
		
		final JButton btnNewButton_2 = new JButton("CLEAR");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_2.setBounds(463, 479, 189, 39);
		frame.getContentPane().add(btnNewButton_2);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  if (e.getSource() == btnNewButton_2) {
					  textField.setText("");
					  textField_1.setText("");
					  textField_2.setText("");
					  textField_3.setText("");
					  textField_4.setText("");
					  textField_5.setText("");
					  textField_6.setText("");
					  textField_7.setText("");
					  textField_8.setText("");
			        }
			}
		});
		
	}
}
